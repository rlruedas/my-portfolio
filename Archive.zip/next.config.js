module.exports = {
    reactStrictMode: true,
}